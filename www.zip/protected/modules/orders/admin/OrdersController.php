<?php
/*
 * вывод каталога компаний и их данных
 */
class OrdersController extends BaseController{
	
	protected $params;
	protected $db;
	private $left_menu = array(array('title'=>'Незавершенные заказы', 
									 'url'=>'/admin/orders/act/incomplete', 
									 'name'=>'incomplete'),

                                array('title'=>'Экспорт данных',
                                    'url'=>'/admin/orders/act/export',
                                    'name'=>'export'));
	
	function  __construct($registry, $params)
	{
		parent::__construct($registry, $params);
		$this->tb = "orders";
		$this->name = "Заказы";
		$this->registry = $registry;
		$this->orders = new Orders($this->sets);
	}

	public function indexAction()
	{
		$vars['message'] = '';
		$vars['name'] = $this->name;
		if(isset($this->params['act']))
		{
			$act=$this->params['act'].'Action';
			return $this->Index($this->$act());
		}
		
		if(isset($this->params['subsystem']))return $this->Index($this->orders->subsystemAction());
		if(isset($this->registry['access']))$vars['message'] = $this->orders->registry['access'];
		if(isset($this->params['delete'])||isset($_POST['delete']))$vars['message'] = $this->orders->delete();
		elseif(isset($_POST['update']))$vars['message'] = $this->orders->save();
		elseif(isset($_POST['update_close']))$vars['message'] = $this->orders->save();
		elseif(isset($_POST['add_close']))$vars['message'] = $this->orders->add();

		$vars['currency'] = $this->db->row("SELECT icon FROM currency WHERE `base`='1'");
		$vars['status'] = $this->db->rows("SELECT * FROM orders_status ORDER BY id ASC");
		
		
		if(isset($_POST['word']))
        {
			$_SESSION['search_order']['status']=$_POST['status'];
            $_SESSION['search_order']['sort']=$_POST['sort'];
            $_SESSION['search_order']['word']=$_POST['word'];
        }
		
		$where="tb.id!='0' ";
		if(!isset($_SESSION['search_order'])||isset($_POST['clear']))
		{
			$_SESSION['search_order']['status']='';
			$_SESSION['search_order']['cat_id']='';
			$_SESSION['search_order']['word']='';
			$_SESSION['search_order']['sort']='ORDER BY tb.`start_date` DESC';
		}
		
		if($_SESSION['search_order']['status']!='')
		{
			$where.=" AND tb.status_id='{$_SESSION['search_order']['status']}'";	
		}
		/*
		if($_SESSION['search_user']['rating']!='')
		{
			$where.=" AND tb.rating='{$_SESSION['search_user']['rating']}'";	
		}*/
		
		if($_SESSION['search_order']['word']!="")
		 	$where.="AND (tb.username LIKE '%{$_SESSION['search_order']['word']}%' OR 
						  tb.city LIKE '%{$_SESSION['search_order']['word']}%' OR 
						  tb.email LIKE '%{$_SESSION['search_order']['word']}%' OR 
						  tb.phone LIKE '%{$_SESSION['search_order']['word']}%' OR 
						  tb.address LIKE '%{$_SESSION['search_order']['word']}%'
						  )";
		
		$sort='tb.`date_add` DESC';
		
		if(isset($_SESSION['search_order']['sort'])&&$_SESSION['search_order']['sort']!='')
		{
			if($_SESSION['search_order']['sort']=='name asc')$sort="tb.username ASC, tb.id DESC"; 
			elseif($_SESSION['search_order']['sort']=='name desc')$sort="tb.username DESC, tb.id DESC";
			elseif($_SESSION['search_order']['sort']=='email asc')$sort="tb.email ASC, tb.id DESC";
			elseif($_SESSION['search_order']['sort']=='email desc')$sort="tb.email DESC, tb.id DESC";
			elseif($_SESSION['search_order']['sort']=='date asc')$sort="tb.date_add ASC, tb.id DESC";
			
			elseif($_SESSION['search_order']['sort']=='price asc')$sort="`sum` ASC, tb.id DESC";
			elseif($_SESSION['search_order']['sort']=='price desc')$sort="`sum` DESC, tb.id DESC";
		}

		$vars['list'] = $this->orders->find(array('paging'=>true, 
												  'order'=>$sort, 
												  'where'=>$where, 
												  'select'=>'tb.*, tb2.name as status, c.icon, c.position',
												  'join'=>'LEFT JOIN orders_status tb2 ON tb.status_id=tb2.id
												  		   LEFT JOIN currency c ON tb.currency=c.id'));
												  
		$vars['list'] = $this->view->Render('view.phtml', $vars);
		$data['left_menu'] = $this->model->left_menu_admin(array('action'=>$this->tb, 'name'=>$this->name, 'menu2'=>$this->left_menu));
		$data['content'] = $this->view->Render('list.phtml', $vars);
		return $this->Index($data);
	}
	
	public function addAction()
	{
		$vars['message'] = '';
		if(isset($_POST['add']))$vars['message'] = $this->orders->add();
		
		////Delivery
		$row = $this->db->row("SELECT id FROM modules WHERE `controller`=?", array('delivery'));
		if($row)$vars['delivery'] = Delivery::getObject($this->sets)->find(array('type'=>'rows', 'where'=>'__tb.active:=1__', 'order'=>'tb.sort ASC'));
		
		////Payment
		$row = $this->db->row("SELECT id FROM modules WHERE `controller`=?", array('payment'));
		if($row)$vars['payment'] = Payment::getObject($this->sets)->find(array('type'=>'rows', 'where'=>'__tb.active:=1__', 'order'=>'tb.sort ASC'));
		$data['content'] = $this->view->Render('add.phtml', $vars);
		return $this->Index($data);
	}
	
	public function editAction()
	{
		$vars['message'] = '';		
		if(isset($this->params['del']))
		{
			$vars['message'] = $this->orders->del_product($this->params['del']);
		}
		
		if(isset($_POST['update']))$vars['message'] = $this->orders->save();
		$vars['status'] = $this->db->rows("SELECT * FROM orders_status");
											
		$vars['catalog'] = Catalog::getObject($this->sets)->find(array('type'=>'rows', 'where'=>'__tb.active:=1__', 'order'=>'tb.sort ASC'));
		$vars['edit'] = $this->orders->find((int)$this->params['edit']);
		
		
		
		////Delivery
		$row = $this->db->row("SELECT id FROM modules WHERE `controller`=?", array('delivery'));
		if($row)$vars['delivery'] = Delivery::getObject($this->sets)->find(array('type'=>'rows', 'where'=>'__tb.active:=1__', 'order'=>'tb.sort ASC'));
		
		////Payment
		$row = $this->db->row("SELECT id FROM modules WHERE `controller`=?", array('payment'));
		if($row)$vars['payment'] = Payment::getObject($this->sets)->find(array('type'=>'rows', 'where'=>'__tb.active:=1__', 'order'=>'tb.sort ASC'));
		
		$vars['currency'] = $this->db->row("SELECT icon FROM currency WHERE `base`='1'");
		$vars['currency2'] = $this->db->row("SELECT * FROM currency WHERE `id`='{$vars['edit']['currency']}'");	
			
		$product = $this->db->rows("SELECT tb.*, p.photo, tb.photo AS photo_basket, p.url FROM orders_product tb
											LEFT JOIN product p
											ON p.id=tb.product_id
											WHERE orders_id=?", array($this->params['edit']));
											
		$vars['product'] = $this->view->Render('orderproduct.phtml', array('product'=>$product, 'currency'=>$vars['currency'], 'total'=>$vars['edit']['sum'], 'order_id'=>$vars['edit']['id']));
									
		$data['content'] = $this->view->Render('edit.phtml', $vars);
		return $this->Index($data);
	}
	
	public function incompleteAction()
	{
		$vars = $this->orders->incomplete();
											
		$data['styles'] = array('jquery.simple-dtpicker.css');
		$data['scripts'] = array('jquery.simple-dtpicker.js');									
		$data['left_menu'] = $this->model->left_menu_admin(array('action'=>$this->tb, 'name'=>$this->name, 'sub'=>'incomplete', 'menu2'=>$this->left_menu));
		$data['content'] = $this->view->Render('incomplete.phtml', $vars);
		return $data;
	}
	
	
	/////Load list product in select
	function orderProductAction()
    {
		return Orders::getObject($this->sets)->orderProduct();
    }
	
	////Load table product view
	function orderProductViewAction()
    {
		$this->registry->set('admin', 'orders');
		$data = Orders::getObject($this->sets)->orderProductView();
		$data['content']=$this->view->Render('orderproduct.phtml', array('product'=>$data['res'], 'total'=>$data['total'], 'currency'=>$data['currency'], 'order_id'=>$_POST['order_id']));
		return json_encode($data);
    }
	
	public function exportAction()
    {
        if(isset($_POST['download'])) {

            $selectedColumns = implode(', ', $_POST['columns']);
            $dataSet = $this->orders->find(array('select'=> $selectedColumns, 'type'=>'rows'));

            $save = 'export'.strtoupper($_POST['file_format']);
            Export::$save($dataSet);
        }

        $vars['name'] = 'Экспорт - ' . $this->name;
        $vars['action'] = $this->tb;
        $vars['path'] = '/act/export';

        $vars['columns'] = $this->db->rows("SHOW COLUMNS FROM " .$this->tb);
        $data['left_menu'] = $this->model->left_menu_admin(array('action'=>$this->tb, 'name'=>$this->name, 'sub'=>'export', 'menu2'=>$this->left_menu));
        $data['content'] = $this->view->Render('export.phtml', $vars);
        return $data;
    }
}
?>